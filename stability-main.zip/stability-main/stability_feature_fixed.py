"""
PV Stability Analysis Tool - Restructured Main App
====================================================

New workflow:
1. Parse Data - View data grouped by device (collapsible)
2. Filter Raw Data - Apply filters to remove abnormalities
3. View Statistics - Auto-calculated after filtering
4. Analysis - Interactive time-series plots (PCE, Jsc, Voc, FF)
"""

from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from data_parser import (
    discover_stability_files,
    build_device_data_map,
    build_raw_data_table,
    process_uploaded_files,
)
from database import StabilityDatabase


# ============================================================================
# HELPER FUNCTION: APPLY MISMATCH FACTORS
# ============================================================================

def apply_mismatch_factors(data: pd.DataFrame, mismatch_factors: list) -> pd.DataFrame:
    """
    Apply mismatch factors to correct Jsc and PCE values for specific days (batches).
    
    Correction formula:
      Corrected Jsc = Jsc / Mismatch Factor
      Corrected PCE = Corrected Jsc * Voc * FF / 100
    
    The mismatch factor represents a measurement correction factor. A factor < 1.0
    means the measurement is lower than the true value, so dividing by it increases
    the corrected value. A factor > 1.0 means the measurement is higher, so dividing
    by it decreases the corrected value.
    
    Args:
        data: DataFrame with columns including 'day', 'jsc', 'voc', 'ff'
        mismatch_factors: List of tuples (day_num, mismatch_factor)
                         Correction factor (typically 0.5-1.5)
                         Applies correction to all devices on that day
    
    Returns:
        DataFrame with corrected Jsc and PCE in 'jsc_corrected' and 'pce_corrected' columns
    """
    if data.empty:
        return data
    
    adjusted_data = data.copy()
    
    # Initialize corrected columns with original values
    if 'jsc_corrected' not in adjusted_data.columns:
        adjusted_data['jsc_corrected'] = adjusted_data['jsc'].copy()
    
    if 'pce_corrected' not in adjusted_data.columns:
        adjusted_data['pce_corrected'] = adjusted_data['pce'].copy()
    
    # Apply corrections for each day that has a mismatch factor
    if mismatch_factors:
        for day_num, factor in mismatch_factors:
            mask = adjusted_data['day'] == day_num
            # Validate factor is in acceptable range
            if factor <= 0 or factor > 2.0:
                print(f"Warning: Mismatch factor {factor} for Day {day_num} is outside normal range (0-2). Skipping.")
                continue
            # Correct Jsc by dividing by mismatch factor
            # Formula: Corrected Jsc = Jsc / Mismatch Factor
            adjusted_data.loc[mask, 'jsc_corrected'] = adjusted_data.loc[mask, 'jsc'] / factor
            # Calculate corrected PCE: Corrected Jsc * Voc * FF / 100
            adjusted_data.loc[mask, 'pce_corrected'] = (
                adjusted_data.loc[mask, 'jsc_corrected'] * 
                adjusted_data.loc[mask, 'voc'] * 
                adjusted_data.loc[mask, 'ff'] / 100
            )
    
    return adjusted_data


# ============================================================================
# PAGE CONFIGURATION
# ============================================================================

st.set_page_config(
    page_title="PV Stability Analysis",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
    <style>
    .device-header {
        background-color: #e8f4f8;
        padding: 12px;
        border-radius: 6px;
        border-left: 4px solid #0084d6;
        margin: 8px 0;
    }
    .stats-box {
        background-color: #f0f2f6;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
    }
    .filter-box {
        background-color: #fff3cd;
        padding: 15px;
        border-radius: 8px;
        border-left: 4px solid #ffc107;
        margin: 10px 0;
    }
    </style>
    """, unsafe_allow_html=True)

# ============================================================================
# SESSION STATE INITIALIZATION
# ============================================================================

if "db" not in st.session_state:
    st.session_state.db = None

if "raw_data" not in st.session_state:
    st.session_state.raw_data = pd.DataFrame()

if "filtered_data" not in st.session_state:
    st.session_state.filtered_data = pd.DataFrame()

if "device_map" not in st.session_state:
    st.session_state.device_map = {}

if "file_paths" not in st.session_state:
    st.session_state.file_paths = []

if "loaded_files_hash" not in st.session_state:
    st.session_state.loaded_files_hash = None

if "last_data_source" not in st.session_state:
    st.session_state.last_data_source = None

# Mismatch factor adjustments: stores list of (day, mismatch_factor) tuples
# Applied to all devices on that day
if "mismatch_factors" not in st.session_state:
    st.session_state.mismatch_factors = []


# ============================================================================
# SIDEBAR - DATA LOADING
# ============================================================================

st.sidebar.markdown("# 📂 Load Data")
st.sidebar.markdown("---")

data_source = st.sidebar.radio(
    "Data source:",
    options=["Script Folder", "Custom Folder", "Upload Files"],
    index=0
)

# IMPORTANT: Only rebuild file_paths if data_source changed
data_source_changed = (st.session_state.last_data_source != data_source)
file_paths = []

if data_source_changed or not st.session_state.file_paths:
    # Data source changed or no files loaded yet - rebuild file list
    if data_source == "Script Folder":
        try:
            base_dir = Path(os.path.dirname(os.path.abspath(__file__)))
            file_paths = sorted(discover_stability_files(base_dir))
            if file_paths:
                st.sidebar.success(f"✓ Found {len(file_paths)} files")
            else:
                st.sidebar.info("No files found in script folder")
        except Exception as e:
            st.sidebar.error(f"Error: {e}")
    
    elif data_source == "Custom Folder":
        data_dir = st.sidebar.text_input("Enter folder path:", placeholder="/path/to/data")
        if data_dir:
            base = Path(data_dir).expanduser()
            if base.exists() and base.is_dir():
                file_paths = sorted(discover_stability_files(base))
                if file_paths:
                    st.sidebar.success(f"✓ Found {len(file_paths)} files")
                else:
                    st.sidebar.warning("No matching files found")
            else:
                st.sidebar.error(f"Directory not found")
    
    elif data_source == "Upload Files":
        uploaded_files = st.sidebar.file_uploader(
            "Upload files:",
            type=["txt", "zip"],
            accept_multiple_files=True,
        )
        if uploaded_files:
            try:
                file_paths = sorted(process_uploaded_files(uploaded_files))
                st.sidebar.success(f"✓ Processed {len(file_paths)} files")
            except Exception as e:
                st.sidebar.error(f"Error: {e}")
    
    # Update session state with new file paths
    st.session_state.file_paths = file_paths
    st.session_state.last_data_source = data_source
else:
    # Data source unchanged - use previously loaded files from session state
    file_paths = st.session_state.file_paths

# ============================================================================
# MAIN APP TITLE
# ============================================================================

st.markdown("# 🔬 Photovoltaic Stability Analysis Tool")
st.markdown("**Restructured workflow:** Parse → Filter → Statistics → Analyze")

if not file_paths:
    st.warning("⚠️ No data files found. Please configure a data source in the sidebar.")
    st.stop()

# ============================================================================
# DATA PROCESSING
# ============================================================================

device_map = build_device_data_map(file_paths)
raw_data = build_raw_data_table(device_map)

st.session_state.device_map = device_map
st.session_state.raw_data = raw_data

# IMPORTANT: Preserve filtered_data across reruns
# Use a more robust approach: only reset on data source change, not on widget changes
if st.session_state.filtered_data.empty:
    # First time: initialize filtered_data
    st.session_state.filtered_data = raw_data.copy()
    st.session_state.loaded_files_hash = hash(tuple(file_paths))
elif data_source_changed:
    # Data source actually changed - reset filtered_data
    st.session_state.filtered_data = raw_data.copy()
    st.session_state.loaded_files_hash = hash(tuple(file_paths))
# else: Widget changed (parameter toggle, device selection, etc.) - DON'T RESET!

if raw_data.empty:
    st.error("❌ No valid data could be extracted.")
    st.stop()

# Initialize database with raw data (will be updated when filters are applied)
db = StabilityDatabase(raw_data)
st.session_state.db = db

# ============================================================================
# MAIN TABS
# ============================================================================

tab1, tab2, tab3, tab4 = st.tabs([
    "1️⃣ Parse Data",
    "2️⃣ Filter Raw Data",
    "3️⃣ Statistics",
    "4️⃣ Analysis",
])

# ============================================================================
# TAB 1: PARSE DATA - GROUPED BY DEVICE
# ============================================================================

with tab1:
    st.subheader("📊 Parsed Data - Grouped by Device & Day")
    st.markdown("""
    All measurements are organized by device and day. 
    Click to expand each device and then each day to view measurements with timestamps.
    """)
    
    devices = sorted(device_map.keys())
    
    if not devices:
        st.info("No devices found in data.")
    else:
        st.markdown(f"**Total Devices:** {len(devices)}")
        st.markdown(f"**Total Measurements:** {len(raw_data)}")
        
        st.markdown("---")
        
        # Display each device in a collapsible expander
        for device_num in devices:
            device = device_map[device_num]
            num_measurements = len(raw_data[raw_data['device_number'] == device_num])
            
            # Device-level expander
            with st.expander(
                f"📱 **Device {device_num}** ({num_measurements} measurements)",
                expanded=False
            ):
                # List all day/date groups in this device
                day_entries = sorted(
                    device.days.items(),
                    key=lambda item: (item[1].day, item[1].group_date)
                )
                
                for _, day_data in day_entries:
                    num_day_measurements = len(day_data.measurements)
                    
                    # Day-level expander (nested inside device)
                    with st.expander(
                        f"📅 **Day {day_data.day}** - {day_data.variation} ({day_data.group_date}) ({num_day_measurements} measurements)",
                        expanded=False
                    ):
                        # Day data table
                        day_df = day_data.to_dataframe()
                        if not day_df.empty:
                            day_df['device_number'] = device_num
                            
                            # Display measurements with direction
                            display_cols = ['datetime', 'direction', 'pixel', 'scan', 'jsc', 'voc', 'ff', 'pce']
                            display_df = day_df[display_cols].copy()
                            display_df['datetime'] = display_df['datetime'].astype(str)
                            display_df = display_df.rename(columns={
                                'datetime': 'DateTime',
                                'direction': 'Direction',
                                'pixel': 'Pixel',
                                'scan': 'Scan',
                                'jsc': 'Jsc',
                                'voc': 'Voc',
                                'ff': 'FF',
                                'pce': 'PCE'
                            })
                            
                            st.dataframe(
                                display_df,
                                use_container_width=True,
                                height=300,
                            )
                            
                            # Quick statistics for this day
                            st.markdown("##### Day Statistics (Raw Data):")
                            stat_cols = st.columns(4)
                            
                            for idx, param in enumerate(['jsc', 'voc', 'ff', 'pce']):
                                param_data = day_df[param].dropna()
                                if len(param_data) > 0:
                                    with stat_cols[idx]:
                                        st.metric(
                                            param.upper(),
                                            f"{param_data.mean():.2f}",
                                            f"σ={param_data.std():.2f}"
                                        )

# ============================================================================
# TAB 2: FILTER RAW DATA
# ============================================================================

with tab2:
    st.subheader("🔍 Filter Raw Data")
    st.markdown("Define acceptable ranges for each parameter. Filtered data will be shown below for verification.")
    
    # Get recommendations from raw data
    recommendations = db.get_filter_recommendations()
    
    st.markdown("### Step 1: Set Filter Ranges")
    
    filter_cols = st.columns(4)
    filters_to_apply = {}
    
    params = [
        ("jsc", "Jsc (mA/cm²)", 40),
        ("voc", "Voc (V)", 1),
        ("ff", "FF (%)", 85),
        ("pce", "PCE (%)", 30),
    ]
    
    for idx, (param, label, default_max) in enumerate(params):
        with filter_cols[idx]:
            st.markdown(f"#### {label}")
            
            if param in recommendations:
                rec_min, rec_max = recommendations[param]
                st.caption(f"Recommended: {rec_min:.2f}-{rec_max:.2f}")
                default_min = rec_min
                default_max = rec_max
            else:
                default_min = 0
                default_max = default_max
            
            col_min, col_max = st.columns(2)
            
            with col_min:
                min_val = st.number_input(
                    f"Min",
                    value=default_min,
                    key=f"filter_min_{param}",
                    label_visibility="collapsed"
                )
            
            with col_max:
                max_val = st.number_input(
                    f"Max",
                    value=default_max,
                    key=f"filter_max_{param}",
                    label_visibility="collapsed"
                )
            
            if min_val < max_val and param in raw_data.columns:
                filters_to_apply[param] = (min_val, max_val)
    
    # Apply filters
    st.markdown("---")
    st.markdown("### Step 2: Apply & Verify Filters")
    
    col_apply, col_clear = st.columns(2)
    
    with col_apply:
        if st.button("✅ Apply Filters", use_container_width=True, key="apply_btn"):
            # Apply filters to raw_data
            filtered_raw_data = raw_data.copy()
            
            for param, (min_v, max_v) in filters_to_apply.items():
                filtered_raw_data = filtered_raw_data[
                    (filtered_raw_data[param] >= min_v) & 
                    (filtered_raw_data[param] <= max_v)
                ]
            
            # Initialize corrected columns for all data
            if 'jsc_corrected' not in filtered_raw_data.columns:
                filtered_raw_data['jsc_corrected'] = filtered_raw_data['jsc'].copy()
            if 'pce_corrected' not in filtered_raw_data.columns:
                filtered_raw_data['pce_corrected'] = filtered_raw_data['pce'].copy()
            
            # Apply mismatch factors if any exist
            if st.session_state.mismatch_factors:
                filtered_raw_data = apply_mismatch_factors(
                    filtered_raw_data,
                    st.session_state.mismatch_factors
                )
            
            # Store in session state
            st.session_state.filtered_data = filtered_raw_data
            
            # Rebuild database with filtered data
            db_filtered = StabilityDatabase(filtered_raw_data)
            st.session_state.db = db_filtered
            
            st.success(f"✓ Filters applied! {len(filtered_raw_data)} / {len(raw_data)} records kept")

    
    with col_clear:
        if st.button("❌ Clear Filters", use_container_width=True, key="clear_btn"):
            st.session_state.filtered_data = raw_data.copy()
            st.session_state.mismatch_factors = []  # Also clear mismatch factors
            db_new = StabilityDatabase(raw_data)
            st.session_state.db = db_new
            st.info("Filters and mismatch factors cleared.")
            st.rerun()
    
    # ============================================================================
    # STEP 3: APPLY MISMATCH FACTORS TO BATCHES (ALL DEVICES ON SAME DAY)
    # ============================================================================
    
    st.markdown("---")
    st.markdown("### Step 3: Apply Mismatch Factors (Optional)")
    st.markdown("Adjust Jsc values for specific days (batches) using the mismatch correction factor.")
    st.markdown("""
    **Correction Formula:**
    - **Corrected Jsc = Jsc / Mismatch Factor**
    - **Corrected PCE = Corrected Jsc × Voc × FF / 100**
    
    The mismatch factor represents a measurement correction. For example:
    - Factor 0.95: True value is higher than measured (divide by 0.95 to correct up)
    - Factor 1.05: True value is lower than measured (divide by 1.05 to correct down)
    """)
    
    # Get unique days from filtered data
    filtered_data_current = st.session_state.get('filtered_data', raw_data).copy()
    
    if not filtered_data_current.empty:
        unique_days = sorted(filtered_data_current['day'].unique())
        
        mismatch_cols = st.columns(3)
        
        with mismatch_cols[0]:
            # Day selection
            selected_day = st.selectbox(
                "Select Day (Batch):",
                options=unique_days,
                format_func=lambda d: f"Day {int(d)}",
                key="day_select"
            )
        
        with mismatch_cols[1]:
            # Mismatch factor input via text/number input (0-1)
            mismatch_factor_input = st.text_input(
                "Mismatch Factor (>0):",
                value="0.95",
                placeholder="e.g., 0.95",
                help="Divides Jsc to correct for measurement error (e.g., 0.95 means Corr Jsc = Jsc/0.95)"
            )
            
            # Validate and convert input
            try:
                mismatch_factor = float(mismatch_factor_input)
                if mismatch_factor <= 0 or mismatch_factor > 2.0:
                    st.error("⚠️ Mismatch factor must be between 0 (exclusive) and 2.0")
                    mismatch_factor = None
            except ValueError:
                st.error("⚠️ Invalid number format")
                mismatch_factor = None
        
        with mismatch_cols[2]:
            # Apply button
            if st.button("✅ Apply Factor", use_container_width=True, key="apply_mismatch_btn"):
                if mismatch_factor is not None:
                    # Check if this day already has a factor applied
                    existing_factor = next((f[1] for f in st.session_state.mismatch_factors if f[0] == selected_day), None)
                    
                    if existing_factor is not None:
                        # Update existing factor
                        st.session_state.mismatch_factors = [
                            (d, f) if d != selected_day else (selected_day, mismatch_factor)
                            for d, f in st.session_state.mismatch_factors
                        ]
                        st.info(f"✓ Updated: Day {int(selected_day)} factor → {mismatch_factor}")
                    else:
                        # Add new factor
                        st.session_state.mismatch_factors.append((selected_day, mismatch_factor))
                        st.success(f"✓ Applied mismatch factor {mismatch_factor} to Day {int(selected_day)}")
                    
                    # Update filtered data with all mismatch factors
                    filtered_data_updated = apply_mismatch_factors(
                        st.session_state.filtered_data,
                        st.session_state.mismatch_factors
                    )
                    st.session_state.filtered_data = filtered_data_updated
                    
                    # Rebuild database with updated data
                    db_updated = StabilityDatabase(filtered_data_updated)
                    st.session_state.db = db_updated
                    
                    st.rerun()
        
        # Display applied mismatch factors
        if st.session_state.mismatch_factors:
            st.markdown("---")
            st.markdown("#### 📊 Applied Mismatch Factors:")
            st.markdown("""
            **Formula Applied:** Corrected Jsc = Jsc / Mismatch Factor
            
            Example: If Raw Jsc = 40 mA/cm² and Mismatch Factor = 0.95
            - Corrected Jsc = 40 / 0.95 = 42.1 mA/cm² (correction applied)
            """)
            
            mismatch_df = pd.DataFrame(
                st.session_state.mismatch_factors,
                columns=['Day', 'Mismatch Factor']
            )
            mismatch_df['Day'] = mismatch_df['Day'].astype(int)
            mismatch_df['Devices Affected'] = mismatch_df['Day'].apply(
                lambda d: len(filtered_data_current[filtered_data_current['day'] == d]['device_number'].unique())
            )
            mismatch_df['Records Adjusted'] = mismatch_df['Day'].apply(
                lambda d: len(filtered_data_current[filtered_data_current['day'] == d])
            )
            
            col_display, col_actions = st.columns([3, 1])
            
            with col_display:
                st.dataframe(mismatch_df, use_container_width=True, hide_index=True)
            
            with col_actions:
                st.markdown("#### Actions:")
                if len(st.session_state.mismatch_factors) > 0:
                    remove_idx = st.selectbox(
                        "Remove factor:",
                        options=range(len(st.session_state.mismatch_factors)),
                        format_func=lambda i: f"Day {int(st.session_state.mismatch_factors[i][0])}",
                        key="remove_factor_select"
                    )
                    
                    if st.button("🗑️ Remove", use_container_width=True, key="remove_factor_btn"):
                        del st.session_state.mismatch_factors[remove_idx]
                        st.success("Factor removed.")
                        st.rerun()
            
            st.info("✓ Jsc values corrected using formula: Corrected Jsc = Jsc / Mismatch Factor. Statistics and Analysis will use corrected data.")
    
    # Show filtered data by device and day
    st.markdown("---")
    st.markdown("### Step 4: Verify Filtered Data by Device & Day")
    
    # Use filtered data from session state
    filtered_data_current = st.session_state.get('filtered_data', raw_data).copy()
    
    if filtered_data_current.empty:
        st.warning("No data matches the current filters.")
    else:
        devices_with_data = sorted(filtered_data_current['device_number'].unique())
        
        for device_num in devices_with_data:
            device_data_filtered = filtered_data_current[filtered_data_current['device_number'] == device_num]
            days_in_device = sorted(device_data_filtered['day'].unique())
            
            with st.expander(f"📱 Device {device_num} ({len(device_data_filtered)} records)", expanded=False):
                for day_num in days_in_device:
                    day_filtered = device_data_filtered[device_data_filtered['day'] == day_num]
                    variation = day_filtered['variation'].iloc[0] if not day_filtered.empty else "Unknown"
                    
                    with st.expander(f"📅 Day {day_num} - {variation} ({len(day_filtered)} records)"):
                        # Display filtered data for this day with mismatch correction
                        display_filtered = day_filtered[['datetime', 'direction', 'pixel', 'jsc', 'voc', 'ff', 'pce']].copy()
                        
                        # Add corrected columns if they exist in the day_filtered data
                        if 'jsc_corrected' in day_filtered.columns:
                            display_filtered['jsc_corrected'] = day_filtered['jsc_corrected']
                        if 'pce_corrected' in day_filtered.columns:
                            display_filtered['pce_corrected'] = day_filtered['pce_corrected']
                        
                        display_filtered['datetime'] = display_filtered['datetime'].astype(str)
                        display_filtered = display_filtered.rename(columns={
                            'datetime': 'DateTime',
                            'direction': 'Direction',
                            'pixel': 'Pixel',
                            'jsc': 'Raw Jsc (mA/cm²)',
                            'jsc_corrected': 'Corr Jsc (mA/cm²)',
                            'voc': 'Voc (V)',
                            'ff': 'FF (%)',
                            'pce': 'Raw PCE (%)',
                            'pce_corrected': 'Corr PCE (%)'
                        })
                        
                        st.dataframe(
                            display_filtered,
                            use_container_width=True,
                            height=250,
                        )


# ============================================================================
# TAB 3: STATISTICS
# ============================================================================

with tab3:
    st.subheader("📈 Statistics (From Filtered & Corrected Data)")
    
    # Use filtered data from session state
    filtered_data_for_stats = st.session_state.get('filtered_data', raw_data).copy()
    
    if filtered_data_for_stats.empty:
        st.warning("No statistics available. Check your filters.")
    else:
        # Ensure jsc_corrected and pce_corrected columns exist (for consistency)
        if 'jsc_corrected' not in filtered_data_for_stats.columns:
            filtered_data_for_stats['jsc_corrected'] = filtered_data_for_stats['jsc']
        if 'pce_corrected' not in filtered_data_for_stats.columns:
            filtered_data_for_stats['pce_corrected'] = filtered_data_for_stats['pce']
        
        # Overall statistics
        st.markdown("### Overall Statistics (Corrected Data)")
        
        stat_cols = st.columns(4)
        param_list = ["jsc_corrected", "voc", "ff", "pce_corrected"]
        param_labels = ["Jsc Corrected (mA/cm²)", "Voc (V)", "FF (%)", "PCE Corrected (%)"]
        
        for idx, (param, label) in enumerate(zip(param_list, param_labels)):
            if param in filtered_data_for_stats.columns:
                param_data = filtered_data_for_stats[param].dropna()
                if len(param_data) > 0:
                    with stat_cols[idx]:
                        st.markdown(f"#### {label}")
                        st.text(f"Mean: {param_data.mean():.3f}")
                        st.text(f"Median: {param_data.median():.3f}")
                        st.text(f"Std: {param_data.std():.3f}")
                        st.text(f"Min: {param_data.min():.3f}")
                        st.text(f"Max: {param_data.max():.3f}")
                        st.text(f"Count: {len(param_data)}")
        
        # Device breakdown
        st.markdown("---")
        st.markdown("### Statistics by Device (Corrected Data)")
        
        if not filtered_data_for_stats.empty:
            devices_in_data = sorted(filtered_data_for_stats['device_number'].unique())
            
            device_tabs = st.tabs([f"Device {d}" for d in devices_in_data])
            
            for idx, device_num in enumerate(devices_in_data):
                with device_tabs[idx]:
                    device_data = filtered_data_for_stats[filtered_data_for_stats['device_number'] == device_num]
                    
                    device_stats = st.columns(4)
                    
                    # Use corrected Jsc and PCE for statistics
                    params_to_show = ['jsc_corrected', 'voc', 'ff', 'pce_corrected']
                    param_labels_show = ['JSC CORRECTED', 'VOC', 'FF', 'PCE CORRECTED']
                    
                    for param_idx, (param, param_label) in enumerate(zip(params_to_show, param_labels_show)):
                        param_data = device_data[param].dropna()
                        if len(param_data) > 0:
                            with device_stats[param_idx]:
                                st.metric(
                                    param_label,
                                    f"{param_data.mean():.2f}",
                                    f"n={len(param_data)}"
                                )
                    
                    # Best pixel analysis for this device - use corrected PCE
                    st.markdown("---")
                    st.markdown("##### 📍 Best Pixel Performance (by Corrected PCE)")
                    
                    if 'pixel' in device_data.columns and 'pce_corrected' in device_data.columns:
                        # Find best pixel by average corrected PCE
                        pixel_pce = device_data.groupby('pixel')['pce_corrected'].agg(['mean', 'std', 'count']).reset_index()
                        pixel_pce = pixel_pce.sort_values('mean', ascending=False)
                        
                        if not pixel_pce.empty:
                            best_pixel = pixel_pce.iloc[0]
                            
                            px_col1, px_col2, px_col3 = st.columns(3)
                            
                            with px_col1:
                                st.metric(
                                    "🏆 Best Pixel",
                                    f"{best_pixel['pixel']}",
                                    f"PCE: {best_pixel['mean']:.2f}%"
                                )
                            
                            with px_col2:
                                st.metric(
                                    "Std Dev",
                                    f"{best_pixel['std']:.2f}",
                                )
                            
                            with px_col3:
                                st.metric(
                                    "Measurements",
                                    f"{int(best_pixel['count'])}",
                                )
                            
                            # Show all pixels ranking
                            with st.expander("📊 All Pixels Ranking"):
                                ranking_df = pixel_pce[['pixel', 'mean', 'std', 'count']].copy()
                                ranking_df = ranking_df.rename(columns={
                                    'pixel': 'Pixel',
                                    'mean': 'Avg PCE (%)',
                                    'std': 'Std Dev',
                                    'count': 'Count'
                                })
                                ranking_df['Rank'] = range(1, len(ranking_df) + 1)
                                ranking_df = ranking_df[[
                                    'Rank', 'Pixel', 'Avg PCE (%)', 'Std Dev', 'Count'
                                ]]
                                st.dataframe(ranking_df, use_container_width=True)

# ============================================================================
# TAB 4: ANALYSIS - INTERACTIVE PLOTS
# ============================================================================

with tab4:
    st.subheader("📊 Analysis - Time Series Plots")
    
    # Use filtered data from session state
    filtered_data_for_analysis = st.session_state.get('filtered_data', raw_data)
    
    if filtered_data_for_analysis.empty:
        st.warning("No data available. Check your filters.")
    else:
        devices_list = sorted(filtered_data_for_analysis['device_number'].unique())
        
        # Analysis mode selection (Parameter vs Pixel)
        analysis_tabs = st.tabs(["📈 Parameter Analysis", "📍 Pixel Stability", "📊 Best Pixel Overlay"])
        
        # ============================================================================
        # ANALYSIS TAB 1: PARAMETER ANALYSIS (Original functionality)
        # ============================================================================
        
        with analysis_tabs[0]:
            st.markdown("### 📈 Parameter Analysis (Using Corrected Data)")
            
            # Device selection
            col1, col2, col3 = st.columns([2, 1, 1])
        
            with col1:
                selected_devices = st.multiselect(
                    "Select devices to analyze:",
                    options=devices_list,
                    default=devices_list if devices_list else [],
                )
        
            with col2:
                parameter = st.radio(
                    "Parameter:",
                    options=["PCE (Corrected)", "Jsc (Corrected)", "Voc", "FF"],
                    index=0,
                )
        
            with col3:
                plot_mode = st.radio(
                    "Plot Mode:",
                    options=["Default", "Normalized"],
                    index=0,
                )
        
            if not selected_devices:
                st.warning("Please select at least one device.")
            else:
                # Ensure corrected columns exist
                analysis_data = filtered_data_for_analysis.copy()
                if 'jsc_corrected' not in analysis_data.columns:
                    analysis_data['jsc_corrected'] = analysis_data['jsc']
                if 'pce_corrected' not in analysis_data.columns:
                    analysis_data['pce_corrected'] = analysis_data['pce']
                
                filtered_data_for_analysis = analysis_data
                
                # Map parameter to column name (use corrected values)
                param_map = {
                    "PCE (Corrected)": "pce_corrected",
                    "Jsc (Corrected)": "jsc_corrected",
                    "Voc": "voc",
                    "FF": "ff",
                }
                param_col = param_map[parameter]
                
                # Get data for selected devices from filtered data
                plot_data_all = filtered_data_for_analysis[filtered_data_for_analysis['device_number'].isin(selected_devices)].copy()
                
                if plot_data_all.empty or param_col not in plot_data_all.columns:
                    st.error(f"No valid data for {parameter}.")
                else:
                    # Remove NaN values from the specific parameter column being plotted (not just pce)
                    plot_data_all = plot_data_all[plot_data_all[param_col].notna()].copy()
                    
                    if plot_data_all.empty:
                        st.warning(f"No valid {parameter} values found.")
                    else:
                        # Select BEST (max value of the actual parameter being plotted) for each device per day
                        # This ensures we get the best measurement for the SPECIFIC parameter, not always based on PCE
                        plot_data_best = plot_data_all.loc[plot_data_all.groupby(['device_number', 'day'])[param_col].idxmax()].copy()
                        plot_data_best = plot_data_best[plot_data_best[param_col].notna()].copy()
                        plot_data_best = plot_data_best.sort_values('datetime')
                        
                        if plot_data_best.empty:
                            st.warning(f"No valid {parameter} values found in best measurements.")
                        else:
                            # Calculate total hours from start of dataset
                            min_datetime = plot_data_best['datetime'].min()
                            plot_data_best['hours_from_start'] = (plot_data_best['datetime'] - min_datetime).dt.total_seconds() / 3600
                        
                        # Apply normalization if selected
                        if plot_mode == "Normalized":
                            # Normalize parameter relative to first measurement value (by device)
                            # This shows degradation/change from baseline
                            plot_data_best['plot_value'] = plot_data_best[param_col]
                            norm_info_parts = []
                            
                            for device_num in selected_devices:
                                device_mask = plot_data_best['device_number'] == device_num
                                device_data = plot_data_best[device_mask]
                                
                                if not device_data.empty:
                                    # Get first (earliest) measurement for this device
                                    first_idx = device_data['datetime'].idxmin()
                                    first_value = device_data.loc[first_idx, param_col]
                                    
                                    if first_value > 0:
                                        # Normalize: value / first_value (ratio relative to baseline)
                                        plot_data_best.loc[device_mask, 'plot_value'] = device_data[param_col] / first_value
                                        norm_info_parts.append(f"Device {device_num}: baseline={first_value:.3f}")
                            
                            norm_info = f"(Normalized relative to first value - " + ", ".join(norm_info_parts) + ")"
                        else:
                            plot_data_best['plot_value'] = plot_data_best[param_col]
                            norm_info = ""
                        
                        st.info(f"📊 Showing BEST {parameter} for each device per day ({len(plot_data_best)} measurements) {norm_info}")
                        
                        # Create interactive plot
                        fig = go.Figure()
                        
                        # Add trace for each device
                        for device_num in selected_devices:
                            device_data = plot_data_best[plot_data_best['device_number'] == device_num]
                            
                            if not device_data.empty:
                                # Create hover text with day information
                                hover_text = []
                                for idx, row in device_data.iterrows():
                                    if plot_mode == "Normalized":
                                        text = f"<b>Device {device_num}</b><br>" + \
                                               f"Time: {row['datetime']}<br>" + \
                                               f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                               f"Day: {int(row['day'])}<br>" + \
                                               f"Direction: {row['direction']}<br>" + \
                                               f"{parameter} (normalized): {row['plot_value']:.3f}<br>" + \
                                               f"{parameter} (original): {row[param_col]:.3f}"
                                    else:
                                        text = f"<b>Device {device_num}</b><br>" + \
                                               f"Time: {row['datetime']}<br>" + \
                                               f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                               f"Day: {int(row['day'])}<br>" + \
                                               f"Direction: {row['direction']}<br>" + \
                                               f"{parameter}: {row[param_col]:.3f}"
                                    hover_text.append(text)
                                
                                fig.add_trace(go.Scatter(
                                    x=device_data['hours_from_start'],
                                    y=device_data['plot_value'],
                                    mode='lines+markers',
                                    name=f'Device {device_num}',
                                    customdata=hover_text,
                                    hovertemplate='%{customdata}<extra></extra>',
                                ))
                        
                        # Update layout
                        param_label = {
                            "jsc_corrected": "Jsc Corrected (mA/cm²)",
                            "pce_corrected": "PCE Corrected (%)",
                            "voc": "Voc (V)",
                            "ff": "FF (%)",
                        }[param_col]
                        
                        if plot_mode == "Normalized":
                            yaxis_title = f"{param_label} (Relative to First Value)"
                            plot_title = f"{parameter} vs Time - Normalized by First Value (Best PCE per Device/Day)"
                        else:
                            yaxis_title = param_label
                            plot_title = f"{parameter} vs Time (Best PCE per Device/Day)"
                        
                        fig.update_layout(
                            title=plot_title,
                            xaxis_title="Hours from Start",
                            yaxis_title=yaxis_title,
                            hovermode='x unified',
                            height=500,
                            template='plotly_white',
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)

                        # Download button for the plot with PNG/HTML fallback
                        col_dl1, col_dl2 = st.columns(2)
                        try:
                            plot_bytes = fig.to_image(format="png", width=1200, height=800, scale=2)
                            with col_dl1:
                                st.download_button(
                                    label="📥 Download Plot as PNG",
                                    data=plot_bytes,
                                    file_name=f"parameter_analysis_{parameter.lower().replace(' ', '_')}_{'normalized' if plot_mode == 'Normalized' else 'default'}.png",
                                    mime="image/png",
                                    key="download_param_plot"
                                )
                        except Exception:
                            # Fallback to HTML if PNG export fails
                            html_bytes = fig.to_html().encode("utf-8")
                            with col_dl1:
                                st.download_button(
                                    label="📥 Download Plot as HTML",
                                    data=html_bytes,
                                    file_name=f"parameter_analysis_{parameter.lower().replace(' ', '_')}_{'normalized' if plot_mode == 'Normalized' else 'default'}.html",
                                    mime="text/html",
                                    key="download_param_plot"
                                )
                                st.caption("(PNG export unavailable; HTML download available)")

                            # Also provide HTML as alternative
                            with col_dl2:
                                st.download_button(
                                    label="📥 Download Plot as HTML",
                                    data=html_bytes,
                                    file_name=f"parameter_analysis_{parameter.lower().replace(' ', '_')}_{'normalized' if plot_mode == 'Normalized' else 'default'}.html",
                                    mime="text/html",
                                    key="download_param_plot_html"
                                )
                        else:
                            # Also provide HTML as alternative if PNG worked
                            html_bytes = fig.to_html().encode("utf-8")
                            with col_dl2:
                                st.download_button(
                                    label="📥 Download Plot as HTML",
                                    data=html_bytes,
                                    file_name=f"parameter_analysis_{parameter.lower().replace(' ', '_')}_{'normalized' if plot_mode == 'Normalized' else 'default'}.html",
                                    mime="text/html",
                                    key="download_param_plot_html"
                                )

                        # Display data table
                        with st.expander("📋 Show Best Measurements Data"):
                            display_cols = ['device_number', 'day', 'direction', 'datetime', 'pixel', 'jsc', 'voc', 'ff', 'pce']
                            display_df = plot_data_best[display_cols].copy()
                            display_df['datetime'] = display_df['datetime'].astype(str)
                            
                            # Add normalized value column if in normalized mode
                            if plot_mode == "Normalized":
                                display_df['normalized_value'] = plot_data_best['plot_value']
                            
                            display_df = display_df.rename(columns={
                                'device_number': 'Device',
                                'day': 'Day',
                                'direction': 'Direction',
                                'datetime': 'DateTime',
                                'pixel': 'Pixel',
                                'jsc': 'Jsc',
                                'voc': 'Voc',
                                'ff': 'FF',
                                'pce': 'PCE',
                                'normalized_value': f'{parameter} (Relative to 1st)'
                            })
                            
                            st.dataframe(
                                display_df,
                                use_container_width=True,
                                height=400,
                            )
        
        # ============================================================================
        # ANALYSIS TAB 2: PIXEL STABILITY
        # ============================================================================
        
        with analysis_tabs[1]:
            st.markdown("### 📍 Pixel Stability Analysis (Using Corrected Data)")
            st.markdown("Analyze performance across different pixels (A, B, C, D) for selected devices - showing BEST measurements only.")
            
            # Device selection and settings for pixel analysis
            col_px1, col_px2, col_px3, col_px4 = st.columns([2, 1, 1, 1])
            
            with col_px1:
                selected_devices_px = st.multiselect(
                    "Select devices for pixel analysis:",
                    options=devices_list,
                    default=devices_list if devices_list else [],
                    key="pixel_devices"
                )
            
            with col_px2:
                pixel_mode = st.radio(
                    "Pixel View:",
                    options=["Overlay All", "Individual"],
                    index=0,
                    key="pixel_view_mode"
                )
            
            with col_px3:
                param_px = st.radio(
                    "Parameter:",
                    options=["PCE (Corrected)", "Jsc (Corrected)", "Voc", "FF"],
                    index=0,
                    key="pixel_param"
                )
            
            with col_px4:
                plot_mode_px = st.radio(
                    "Plot Mode:",
                    options=["Default", "Normalized"],
                    index=0,
                    key="pixel_plot_mode"
                )
            
            if not selected_devices_px:
                st.warning("Please select at least one device.")
            else:
                # Get pixel stability data
                pixel_data = filtered_data_for_analysis[filtered_data_for_analysis['device_number'].isin(selected_devices_px)].copy()
                
                if pixel_data.empty:
                    st.warning("No pixel data available for selected devices.")
                else:
                    # Ensure corrected columns exist
                    if 'jsc_corrected' not in pixel_data.columns:
                        pixel_data['jsc_corrected'] = pixel_data['jsc']
                    if 'pce_corrected' not in pixel_data.columns:
                        pixel_data['pce_corrected'] = pixel_data['pce']
                    
                    # Map parameter to column name (use corrected values)
                    param_px_col = {
                        "PCE (Corrected)": "pce_corrected",
                        "Jsc (Corrected)": "jsc_corrected",
                        "Voc": "voc",
                        "FF": "ff"
                    }.get(param_px, "pce_corrected")  # Default to corrected PCE
                    
                    # Get unique pixels
                    unique_pixels = sorted(pixel_data['pixel'].unique())
                    
                    # Remove NaN values from the specific parameter column being plotted (not just pce_corrected)
                    pixel_data = pixel_data[pixel_data[param_px_col].notna()].copy()
                    
                    # Select BEST (max value of the actual parameter being plotted) for each device per day per pixel
                    # This ensures we get the best measurement for the SPECIFIC parameter, not always based on PCE
                    pixel_data_best = pixel_data.loc[pixel_data.groupby(['device_number', 'day', 'pixel'])[param_px_col].idxmax()].copy()
                    pixel_data_best = pixel_data_best[pixel_data_best[param_px_col].notna()].copy()
                    
                    # Calculate hours from start of dataset
                    min_datetime = pixel_data_best['datetime'].min()
                    pixel_data_best['hours_from_start'] = (pixel_data_best['datetime'] - min_datetime).dt.total_seconds() / 3600
                    pixel_data_best = pixel_data_best.sort_values('datetime')
                    
                    # Apply normalization if selected
                    if plot_mode_px == "Normalized":
                        # Normalize parameter relative to first measurement value (by device and pixel)
                        pixel_data_best['plot_value'] = pixel_data_best[param_px_col]
                        norm_info_px = []
                        
                        for device_num in selected_devices_px:
                            for pixel in unique_pixels:
                                device_pixel_mask = (pixel_data_best['device_number'] == device_num) & (pixel_data_best['pixel'] == pixel)
                                device_pixel_data = pixel_data_best[device_pixel_mask]
                                
                                if not device_pixel_data.empty:
                                    # Get first (earliest) measurement for this device-pixel combo
                                    first_idx = device_pixel_data['datetime'].idxmin()
                                    first_value = device_pixel_data.loc[first_idx, param_px_col]
                                    
                                    if first_value > 0:
                                        # Normalize: value / first_value
                                        pixel_data_best.loc[device_pixel_mask, 'plot_value'] = device_pixel_data[param_px_col] / first_value
                                        norm_info_px.append(f"Dev{device_num}-Px{pixel}: baseline={first_value:.3f}")
                        
                        norm_info_str = f"(Normalized relative to first value - " + ", ".join(norm_info_px[:3]) + ("..." if len(norm_info_px) > 3 else "") + ")"
                    else:
                        pixel_data_best['plot_value'] = pixel_data_best[param_px_col]
                        norm_info_str = ""
                    
                    st.info(f"📊 Showing BEST {param_px} for each device/day/pixel ({len(pixel_data_best)} measurements) {norm_info_str}")
                    
                    if pixel_mode == "Overlay All":
                        # Plot all pixels overlaid for each device
                        for device_num in selected_devices_px:
                            device_pixel_data = pixel_data_best[pixel_data_best['device_number'] == device_num]
                            
                            if not device_pixel_data.empty:
                                st.markdown(f"#### Device {device_num}")
                                
                                fig_px = go.Figure()
                                
                                # Add trace for each pixel
                                for pixel in unique_pixels:
                                    pixel_device_data = device_pixel_data[device_pixel_data['pixel'] == pixel].copy()
                                    
                                    if not pixel_device_data.empty:
                                        param_data = pixel_device_data[param_px_col].dropna()
                                        
                                        if len(param_data) > 0:
                                            hover_text = []
                                            for idx, row in pixel_device_data.iterrows():
                                                if plot_mode_px == "Normalized":
                                                    text = f"<b>Device {device_num} - Pixel {pixel}</b><br>" + \
                                                           f"Time: {row['datetime']}<br>" + \
                                                           f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                           f"Day: {int(row['day'])}<br>" + \
                                                           f"Direction: {row['direction']}<br>" + \
                                                           f"{param_px} (normalized): {row['plot_value']:.3f}<br>" + \
                                                           f"{param_px} (original): {row[param_px_col]:.3f}"
                                                else:
                                                    text = f"<b>Device {device_num} - Pixel {pixel}</b><br>" + \
                                                           f"Time: {row['datetime']}<br>" + \
                                                           f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                           f"Day: {int(row['day'])}<br>" + \
                                                           f"Direction: {row['direction']}<br>" + \
                                                           f"{param_px}: {row[param_px_col]:.3f}"
                                                hover_text.append(text)
                                            
                                            fig_px.add_trace(go.Scatter(
                                                x=pixel_device_data['hours_from_start'],
                                                y=pixel_device_data['plot_value'],
                                                mode='lines+markers',
                                                name=f'Pixel {pixel}',
                                                customdata=hover_text,
                                                hovertemplate='%{customdata}<extra></extra>',
                                            ))
                                
                                # Update layout
                                param_label_px = {
                                    "jsc_corrected": "Jsc Corrected (mA/cm²)",
                                    "pce_corrected": "PCE Corrected (%)",
                                    "voc": "Voc (V)",
                                    "ff": "FF (%)",
                                }[param_px_col]
                                
                                if plot_mode_px == "Normalized":
                                    yaxis_title_px = f"{param_label_px} (Relative to First Value)"
                                    plot_title_px = f"Device {device_num} - Pixel Stability ({param_px}) - Normalized"
                                else:
                                    yaxis_title_px = param_label_px
                                    plot_title_px = f"Device {device_num} - Pixel Stability ({param_px})"
                                
                                fig_px.update_layout(
                                    title=plot_title_px,
                                    xaxis_title="Hours from Start",
                                    yaxis_title=yaxis_title_px,
                                    hovermode='x unified',
                                    height=400,
                                    template='plotly_white',
                                )
                                
                                st.plotly_chart(fig_px, use_container_width=True)

                                # Download button for the plot with PNG/HTML fallback
                                col_dl_px1, col_dl_px2 = st.columns(2)
                                try:
                                    plot_bytes_px = fig_px.to_image(format="png", width=1200, height=800, scale=2)
                                    with col_dl_px1:
                                        st.download_button(
                                            label="📥 Download Plot as PNG",
                                            data=plot_bytes_px,
                                            file_name=f"pixel_stability_device_{device_num}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.png",
                                            mime="image/png",
                                            key=f"download_pixel_plot_{device_num}"
                                        )
                                except Exception:
                                    # Fallback to HTML if PNG export fails
                                    html_bytes_px = fig_px.to_html().encode("utf-8")
                                    with col_dl_px1:
                                        st.download_button(
                                            label="📥 Download Plot as HTML",
                                            data=html_bytes_px,
                                            file_name=f"pixel_stability_device_{device_num}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                            mime="text/html",
                                            key=f"download_pixel_plot_{device_num}"
                                        )
                                        st.caption("(PNG export unavailable; HTML download available)")

                                    # Also provide HTML as alternative
                                    with col_dl_px2:
                                        st.download_button(
                                            label="📥 Download Plot as HTML",
                                            data=html_bytes_px,
                                            file_name=f"pixel_stability_device_{device_num}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                            mime="text/html",
                                            key=f"download_pixel_plot_{device_num}_html"
                                        )
                                else:
                                    # Also provide HTML as alternative if PNG worked
                                    html_bytes_px = fig_px.to_html().encode("utf-8")
                                    with col_dl_px2:
                                        st.download_button(
                                            label="📥 Download Plot as HTML",
                                            data=html_bytes_px,
                                            file_name=f"pixel_stability_device_{device_num}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                            mime="text/html",
                                            key=f"download_pixel_plot_{device_num}_html"
                                        )
                    
                    else:  # Individual pixel view
                        st.markdown("#### Individual Pixel Performance")
                        
                        # Pixel selector
                        pixel_selector = st.selectbox("Select pixel to view:", unique_pixels)
                        
                        pixel_individual_data = pixel_data_best[pixel_data_best['pixel'] == pixel_selector].copy()
                        
                        if not pixel_individual_data.empty:
                            fig_ind = go.Figure()
                            
                            for device_num in selected_devices_px:
                                device_px_data = pixel_individual_data[pixel_individual_data['device_number'] == device_num].copy()
                                
                                if not device_px_data.empty:
                                    hover_text = []
                                    for idx, row in device_px_data.iterrows():
                                        if plot_mode_px == "Normalized":
                                            text = f"<b>Device {device_num} - Pixel {pixel_selector}</b><br>" + \
                                                   f"Time: {row['datetime']}<br>" + \
                                                   f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                   f"Day: {int(row['day'])}<br>" + \
                                                   f"Direction: {row['direction']}<br>" + \
                                                   f"{param_px} (normalized): {row['plot_value']:.3f}<br>" + \
                                                   f"{param_px} (original): {row[param_px_col]:.3f}"
                                        else:
                                            text = f"<b>Device {device_num} - Pixel {pixel_selector}</b><br>" + \
                                                   f"Time: {row['datetime']}<br>" + \
                                                   f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                   f"Day: {int(row['day'])}<br>" + \
                                                   f"Direction: {row['direction']}<br>" + \
                                                   f"{param_px}: {row[param_px_col]:.3f}"
                                        hover_text.append(text)
                                    
                                    fig_ind.add_trace(go.Scatter(
                                        x=device_px_data['hours_from_start'],
                                        y=device_px_data['plot_value'],
                                        mode='lines+markers',
                                        name=f'Device {device_num}',
                                        customdata=hover_text,
                                        hovertemplate='%{customdata}<extra></extra>',
                                    ))
                            
                            # Update layout
                            param_label_px = {
                                "jsc_corrected": "Jsc Corrected (mA/cm²)",
                                "pce_corrected": "PCE Corrected (%)",
                                "voc": "Voc (V)",
                                "ff": "FF (%)",
                            }[param_px_col]
                            
                            if plot_mode_px == "Normalized":
                                yaxis_title_px_ind = f"{param_label_px} (Relative to First Value)"
                                plot_title_px_ind = f"Pixel {pixel_selector} - Stability Across Devices ({param_px}) - Normalized"
                            else:
                                yaxis_title_px_ind = param_label_px
                                plot_title_px_ind = f"Pixel {pixel_selector} - Stability Across Devices ({param_px})"
                            
                            fig_ind.update_layout(
                                title=plot_title_px_ind,
                                xaxis_title="Hours from Start",
                                yaxis_title=yaxis_title_px_ind,
                                hovermode='x unified',
                                height=400,
                                template='plotly_white',
                            )
                            
                            st.plotly_chart(fig_ind, use_container_width=True)

                            # Download button for the plot with PNG/HTML fallback
                            col_dl_ind1, col_dl_ind2 = st.columns(2)
                            try:
                                plot_bytes_ind = fig_ind.to_image(format="png", width=1200, height=800, scale=2)
                                with col_dl_ind1:
                                    st.download_button(
                                        label="📥 Download Plot as PNG",
                                        data=plot_bytes_ind,
                                        file_name=f"pixel_individual_{pixel_selector}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.png",
                                        mime="image/png",
                                        key=f"download_individual_pixel_plot_{pixel_selector}"
                                    )
                            except Exception:
                                # Fallback to HTML if PNG export fails
                                html_bytes_ind = fig_ind.to_html().encode("utf-8")
                                with col_dl_ind1:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_ind,
                                        file_name=f"pixel_individual_{pixel_selector}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key=f"download_individual_pixel_plot_{pixel_selector}"
                                    )
                                    st.caption("(PNG export unavailable; HTML download available)")

                                # Also provide HTML as alternative
                                with col_dl_ind2:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_ind,
                                        file_name=f"pixel_individual_{pixel_selector}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key=f"download_individual_pixel_plot_{pixel_selector}_html"
                                    )
                            else:
                                # Also provide HTML as alternative if PNG worked
                                html_bytes_ind = fig_ind.to_html().encode("utf-8")
                                with col_dl_ind2:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_ind,
                                        file_name=f"pixel_individual_{pixel_selector}_{param_px.lower().replace(' ', '_')}_{'normalized' if plot_mode_px == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key=f"download_individual_pixel_plot_{pixel_selector}_html"
                                    )

                            # Show statistics for this pixel
                            st.markdown(f"##### Statistics for Pixel {pixel_selector}")
                            stat_cols_px = st.columns(4)
                            
                            for col_idx, device_num in enumerate(selected_devices_px):
                                device_px = pixel_individual_data[pixel_individual_data['device_number'] == device_num]
                                if not device_px.empty:
                                    param_vals = device_px[param_px_col].dropna()
                                    if len(param_vals) > 0:
                                        with stat_cols_px[col_idx % 4]:
                                            st.metric(
                                                f"Device {device_num}",
                                                f"{param_vals.mean():.2f}",
                                                f"σ={param_vals.std():.2f}"
                                            )


        # ============================================================================
        # ANALYSIS TAB 3: BEST PIXEL OVERLAY
        # ============================================================================

        with analysis_tabs[2]:
            st.markdown("### 📊 Best Pixel Overlay Analysis")
            st.markdown("Overlay different pixel performances from different devices in a single plot. Select which pixel to use for each device.")

            # Device selection and settings for best pixel overlay
            col_bp1, col_bp2, col_bp3 = st.columns([2, 1, 1])

            with col_bp1:
                selected_devices_bp = st.multiselect(
                    "Select devices for overlay:",
                    options=devices_list,
                    default=devices_list if devices_list else [],
                    key="best_pixel_devices"
                )

            with col_bp2:
                param_bp = st.radio(
                    "Parameter:",
                    options=["PCE (Corrected)", "Jsc (Corrected)", "Voc", "FF"],
                    index=0,
                    key="best_pixel_param"
                )

            with col_bp3:
                plot_mode_bp = st.radio(
                    "Plot Mode:",
                    options=["Default", "Normalized"],
                    index=0,
                    key="best_pixel_plot_mode"
                )

            if not selected_devices_bp:
                st.warning("Please select at least one device.")
            else:
                # Get best pixel overlay data
                overlay_data = filtered_data_for_analysis[filtered_data_for_analysis['device_number'].isin(selected_devices_bp)].copy()

                if overlay_data.empty:
                    st.warning("No data available for selected devices.")
                else:
                    # Ensure corrected columns exist
                    if 'jsc_corrected' not in overlay_data.columns:
                        overlay_data['jsc_corrected'] = overlay_data['jsc']
                    if 'pce_corrected' not in overlay_data.columns:
                        overlay_data['pce_corrected'] = overlay_data['pce']

                    # Map parameter to column name (use corrected values)
                    param_bp_col = {
                        "PCE (Corrected)": "pce_corrected",
                        "Jsc (Corrected)": "jsc_corrected",
                        "Voc": "voc",
                        "FF": "ff"
                    }.get(param_bp, "pce_corrected")

                    # Remove NaN values from the specific parameter column being plotted
                    overlay_data = overlay_data[overlay_data[param_bp_col].notna()].copy()

                    if overlay_data.empty:
                        st.warning(f"No valid {param_bp} values found.")
                    else:
                        # Get unique pixels
                        unique_pixels = sorted(overlay_data['pixel'].unique())

                        # Device-pixel selection interface
                        st.markdown("#### Select Pixels for Each Device")
                        device_pixel_selections = {}

                        # Create columns for device-pixel selection
                        num_devices = len(selected_devices_bp)
                        cols_per_row = 3
                        rows = (num_devices + cols_per_row - 1) // cols_per_row

                        for row in range(rows):
                            cols = st.columns(cols_per_row)
                            for col_idx in range(cols_per_row):
                                device_idx = row * cols_per_row + col_idx
                                if device_idx < num_devices:
                                    device_num = selected_devices_bp[device_idx]
                                    with cols[col_idx]:
                                        # Get available pixels for this device
                                        device_pixels = sorted(overlay_data[overlay_data['device_number'] == device_num]['pixel'].unique())
                                        if device_pixels:
                                            selected_pixels = st.multiselect(
                                                f"Device {device_num} pixels:",
                                                options=device_pixels,
                                                default=device_pixels[:1],  # Default to first pixel
                                                key=f"pixel_device_{device_num}"
                                            )
                                            if selected_pixels:
                                                device_pixel_selections[device_num] = selected_pixels

                        # Filter data based on selections and combine
                        combined_overlay_data = []
                        for device_num, selected_pixels in device_pixel_selections.items():
                            for pixel in selected_pixels:
                                device_pixel_data = overlay_data[
                                    (overlay_data['device_number'] == device_num) &
                                    (overlay_data['pixel'] == pixel)
                                ].copy()
                                if not device_pixel_data.empty:
                                    combined_overlay_data.append(device_pixel_data)

                        if not combined_overlay_data:
                            st.warning("No data found for selected device-pixel combinations.")
                        else:
                            pixel_overlay_data = pd.concat(combined_overlay_data, ignore_index=True)

                            # Select BEST (max value of the actual parameter being plotted) for each device-pixel combination per day
                            pixel_overlay_best = pixel_overlay_data.loc[pixel_overlay_data.groupby(['device_number', 'pixel', 'day'])[param_bp_col].idxmax()].copy()
                            pixel_overlay_best = pixel_overlay_best[pixel_overlay_best[param_bp_col].notna()].copy()

                            # Calculate hours from start of dataset
                            min_datetime = pixel_overlay_best['datetime'].min()
                            pixel_overlay_best['hours_from_start'] = (pixel_overlay_best['datetime'] - min_datetime).dt.total_seconds() / 3600
                            pixel_overlay_best = pixel_overlay_best.sort_values('datetime')

                            # Apply normalization if selected
                            if plot_mode_bp == "Normalized":
                                # Normalize parameter relative to first measurement value (by device-pixel combination)
                                pixel_overlay_best['plot_value'] = pixel_overlay_best[param_bp_col]
                                norm_info_bp = []

                                for device_num, selected_pixels in device_pixel_selections.items():
                                    for pixel in selected_pixels:
                                        device_pixel_mask = (pixel_overlay_best['device_number'] == device_num) & (pixel_overlay_best['pixel'] == pixel)
                                        device_pixel_data = pixel_overlay_best[device_pixel_mask]

                                        if not device_pixel_data.empty:
                                            # Get first (earliest) measurement for this device-pixel combo
                                            first_idx = device_pixel_data['datetime'].idxmin()
                                            first_value = device_pixel_data.loc[first_idx, param_bp_col]

                                            if first_value > 0:
                                                # Normalize: value / first_value
                                                pixel_overlay_best.loc[device_pixel_mask, 'plot_value'] = device_pixel_data[param_bp_col] / first_value
                                                norm_info_bp.append(f"Dev{device_num}-Px{pixel}: baseline={first_value:.3f}")

                                norm_info_str_bp = f"(Normalized relative to first value - " + ", ".join(norm_info_bp) + ")"
                            else:
                                pixel_overlay_best['plot_value'] = pixel_overlay_best[param_bp_col]
                                norm_info_str_bp = ""

                            selected_combinations = [f"Dev{dev}-Px{px}" for dev, pixels in device_pixel_selections.items() for px in pixels]
                            st.info(f"📊 Overlaying BEST {param_bp} for {', '.join(selected_combinations)} ({len(pixel_overlay_best)} measurements) {norm_info_str_bp}")

                            # Create overlay plot
                            fig_overlay = go.Figure()

                            # Add trace for each device-pixel combination
                            for device_num, selected_pixels in device_pixel_selections.items():
                                for pixel in selected_pixels:
                                    device_overlay_data = pixel_overlay_best[
                                        (pixel_overlay_best['device_number'] == device_num) &
                                        (pixel_overlay_best['pixel'] == pixel)
                                    ]

                                    if not device_overlay_data.empty:
                                        hover_text = []
                                        for idx, row in device_overlay_data.iterrows():
                                            if plot_mode_bp == "Normalized":
                                                text = f"<b>Device {device_num} - Pixel {pixel}</b><br>" + \
                                                       f"Time: {row['datetime']}<br>" + \
                                                       f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                       f"Day: {int(row['day'])}<br>" + \
                                                       f"Direction: {row['direction']}<br>" + \
                                                       f"{param_bp} (normalized): {row['plot_value']:.3f}<br>" + \
                                                       f"{param_bp} (original): {row[param_bp_col]:.3f}"
                                            else:
                                                text = f"<b>Device {device_num} - Pixel {pixel}</b><br>" + \
                                                       f"Time: {row['datetime']}<br>" + \
                                                       f"Hours from start: {row['hours_from_start']:.1f}h<br>" + \
                                                       f"Day: {int(row['day'])}<br>" + \
                                                       f"Direction: {row['direction']}<br>" + \
                                                       f"{param_bp}: {row[param_bp_col]:.3f}"
                                            hover_text.append(text)

                                        fig_overlay.add_trace(go.Scatter(
                                            x=device_overlay_data['hours_from_start'],
                                            y=device_overlay_data['plot_value'],
                                            mode='lines+markers',
                                            name=f'Device {device_num} - Pixel {pixel}',
                                            customdata=hover_text,
                                            hovertemplate='%{customdata}<extra></extra>',
                                        ))

                            # Update layout
                            param_label_bp = {
                                "jsc_corrected": "Jsc Corrected (mA/cm²)",
                                "pce_corrected": "PCE Corrected (%)",
                                "voc": "Voc (V)",
                                "ff": "FF (%)",
                            }[param_bp_col]

                            if plot_mode_bp == "Normalized":
                                yaxis_title_bp = f"{param_label_bp} (Relative to First Value)"
                                plot_title_bp = f"Device-Pixel Overlay - {param_bp} vs Time (Normalized)"
                            else:
                                yaxis_title_bp = param_label_bp
                                plot_title_bp = f"Device-Pixel Overlay - {param_bp} vs Time"

                            fig_overlay.update_layout(
                                title=plot_title_bp,
                                xaxis_title="Hours from Start",
                                yaxis_title=yaxis_title_bp,
                                hovermode='x unified',
                                height=500,
                                template='plotly_white',
                            )

                            st.plotly_chart(fig_overlay, use_container_width=True)

                            # Download button for the plot with PNG/HTML fallback
                            col_dl_ov1, col_dl_ov2 = st.columns(2)
                            try:
                                plot_bytes_overlay = fig_overlay.to_image(format="png", width=1200, height=800, scale=2)
                                with col_dl_ov1:
                                    st.download_button(
                                        label="📥 Download Plot as PNG",
                                        data=plot_bytes_overlay,
                                        file_name=f"device_pixel_overlay_{param_bp.lower().replace(' ', '_')}_{'normalized' if plot_mode_bp == 'Normalized' else 'default'}.png",
                                        mime="image/png",
                                        key="download_overlay_plot"
                                    )
                            except Exception:
                                # Fallback to HTML if PNG export fails
                                html_bytes_overlay = fig_overlay.to_html().encode("utf-8")
                                with col_dl_ov1:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_overlay,
                                        file_name=f"device_pixel_overlay_{param_bp.lower().replace(' ', '_')}_{'normalized' if plot_mode_bp == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key="download_overlay_plot"
                                    )
                                    st.caption("(PNG export unavailable; HTML download available)")

                                # Also provide HTML as alternative
                                with col_dl_ov2:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_overlay,
                                        file_name=f"device_pixel_overlay_{param_bp.lower().replace(' ', '_')}_{'normalized' if plot_mode_bp == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key="download_overlay_plot_html"
                                    )
                            else:
                                # Also provide HTML as alternative if PNG worked
                                html_bytes_overlay = fig_overlay.to_html().encode("utf-8")
                                with col_dl_ov2:
                                    st.download_button(
                                        label="📥 Download Plot as HTML",
                                        data=html_bytes_overlay,
                                        file_name=f"device_pixel_overlay_{param_bp.lower().replace(' ', '_')}_{'normalized' if plot_mode_bp == 'Normalized' else 'default'}.html",
                                        mime="text/html",
                                        key="download_overlay_plot_html"
                                    )

                            # Display data table
                            with st.expander("📋 Show Overlay Data"):
                                display_cols_bp = ['device_number', 'day', 'direction', 'datetime', 'pixel', 'jsc', 'voc', 'ff', 'pce']
                                display_df_bp = pixel_overlay_best[display_cols_bp].copy()
                                display_df_bp['datetime'] = display_df_bp['datetime'].astype(str)

                                # Add normalized value column if in normalized mode
                                if plot_mode_bp == "Normalized":
                                    display_df_bp['normalized_value'] = pixel_overlay_best['plot_value']

                                display_df_bp = display_df_bp.rename(columns={
                                    'device_number': 'Device',
                                    'day': 'Day',
                                    'direction': 'Direction',
                                    'datetime': 'DateTime',
                                    'pixel': 'Pixel',
                                    'jsc': 'Jsc',
                                    'voc': 'Voc',
                                    'ff': 'FF',
                                    'pce': 'PCE',
                                    'normalized_value': f'{param_bp} (Relative to 1st)'
                                })

                                st.dataframe(
                                    display_df_bp,
                                    use_container_width=True,
                                    height=400,
                                )


# ============================================================================
# FOOTER
# ============================================================================

st.markdown("---")
st.markdown("""
<div style='text-align: center; color: gray; font-size: 11px;'>
    <p>PV Stability Analysis Tool v3.0 | Device-Grouped Data Structure | Timestamp-based Analysis</p>
</div>
""", unsafe_allow_html=True)
